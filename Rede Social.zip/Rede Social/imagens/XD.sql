create database redeSocial
	default character set utf8
	default collate utf8_general_ci;

use redesocial;



	create table Usuario(
	idUsuario integer not null auto_increment,
	email_usuario varchar(45) not null,
	dataNasc_usuario varchar(10) not null,
    senha_usuario varchar(45) not null,
    nome_usuario varchar(45) not null,
    nick_usuario varchar(45) not null,
    telefone_usuario varchar(17) not null,
    primary key (idUsuario)
);

drop table usuario;

select * from usuario;

	CREATE TABLE post (
    idPost INTEGER NOT NULL AUTO_INCREMENT,
    usuario_idUsuario INTEGER NOT NULL,
    title_post VARCHAR(20) NOT NULL,
    body_post VARCHAR(250) NOT NULL,
    tags_post VARCHAR(45) NOT NULL,
    foto_post VARCHAR(255),  -- coluna para o link da foto
    PRIMARY KEY (idPost),
    INDEX Cliente_FKIndex1(usuario_idUsuario)
);


drop table post;

create table comentarioPost(
	idComentarioPost integer not null auto_increment,
    usuarioComentario_idUsuario integer not null,
    title_comentarioPost varchar(20) not null,
    body_comentarioPost varchar(250) not null,
    tags_comentarioPost varchar(45) not null,
    primary key (idPost),
    index Cliente_FKIndex1(usuarioComentario_idUsuario)
);

