//Dependências //Executar da primeira vez
//npm init -y
//npm install express mysql2 dotenv
//npm install cors

//Para executar o servidor
//nodemon server.js

const cors = require('cors');

const express = require('express');
const app = express();
const db = require('./db');
require('dotenv').config();

app.use(express.json());
app.use(cors())

const PORT = process.env.PORT || 3000;

//Rota POST - Cadastrar novo produto
app.post('/cadUsuario', (req, res) => {
  // As variáveis dentro dos {} recebem os dados que vieram do front-end
  const { email_usuario, dataNasc_usuario, senha_usuario, nome_usuario, nick_usuario, telefone_usuario } = req.body;

  //Se os dados que vieram do font-end forem em branco
  if (!email_usuario || !dataNasc_usuario || !senha_usuario || !nome_usuario || !nick_usuario) {
    return res.status(400).json({ error: 'Dados incompletos' });
  }

  //Realiza a inserção dos dados recebidos no banco de dados
  const sql = 'INSERT INTO Usuario (email_usuario, dataNasc_usuario, senha_usuario, nome_usuario, nick_usuario, telefone_usuario) VALUES (?,?,?,?,?,?)';
  db.query(sql, [email_usuario, dataNasc_usuario, senha_usuario, nome_usuario, nick_usuario, telefone_usuario], (err, result) => {
    if (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ error: 'Este usuário já existe' });
      }
      return res.status(500).json({ error: err.message });
    }

    // Em caso de sucesso encaminha uma mensagem e o id do produto
    res.status(201).json({ message: 'Usuário criado com sucesso', id: result.insertId });
  });
});

app.post('/logUsuario', (req, res) => {
  const { email_usuario, nome_usuario, nick_usuario, senha_usuario } = req.body;

  if ((!email_usuario && !nome_usuario && !nick_usuario) || !senha_usuario) {
    return res.status(400).json({ error: 'Dados incompletos' });
  }

  let sql = 'SELECT * FROM Usuario WHERE ';
  let identifier = '';
  let value = '';

  if (email_usuario) {
    identifier = 'email_usuario';
    value = email_usuario;
  } else if (nome_usuario) {
    identifier = 'nome_usuario';
    value = nome_usuario;
  } else if (nick_usuario) {
    identifier = 'nick_usuario';
    value = nick_usuario;
  }

  sql += `${identifier} = ? LIMIT 1`;

  db.query(sql, [value], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (results.length === 0) {
      return res.status(401).json({ error: 'Usuário não encontrado' });
    }

    const usuario = results[0];

    if (usuario.senha_usuario !== senha_usuario) {
      return res.status(401).json({ error: 'Senha incorreta' });
    }

    res.status(200).json({
      message: 'Login realizado com sucesso',
      usuario: {
        id: usuario.id_usuario,
      }
    });
  });
});


// Inicializa o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});